<?php

namespace PayUIndia\Payu\Controller\Standard;

class Response extends \PayUIndia\Payu\Controller\PayuAbstract {
    //Added by Alex
    //private $orderNotifier;

    /*public function __construct(        
        \Magento\Sales\Model\OrderNotifier $orderNotifier
    ) {        
        $this->orderNotifier = $orderNotifier;
    }*/
    public function execute() {
        $returnUrl = $this->getCheckoutHelper()->getUrl('checkout');

        try {
            $paymentMethod = $this->getPaymentMethod();
            $params = $this->getRequest()->getParams();

            if ($paymentMethod->validateResponse($params)) {

                $returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/success');
                $order = $this->getOrder();
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                //$this->orderNotifier->notify($order);
                $objectManager->create('Magento\Sales\Model\OrderNotifier')->notify($order);
                $payment = $order->getPayment();
                $paymentMethod->postProcessing($order, $payment, $params);
                //Added by Alex
                //$this->orderSender->send($order);
            } else {
                //$order = $this->getOrder();
                //$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                //$objectManager->create('Magento\Sales\Model\OrderNotifier')->notify($order);

                $this->messageManager->addErrorMessage(__('Payment failed. Please try again or choose a different payment method'));
                $returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/failure');
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addExceptionMessage($e, $e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('We can\'t place the order.'));
        }

        $this->getResponse()->setRedirect($returnUrl);
    }

}
