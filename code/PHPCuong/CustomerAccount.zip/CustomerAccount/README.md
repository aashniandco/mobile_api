# magento2-customer-ajax-login-and-registration
Magento 2 Customer Ajax Login and Registration

# See the video about this tutorial
- Youtube: https://www.youtube.com/watch?v=UZTJw51m3Xo&index=41&list=PL98CDCbI3TNvPczWSOnpaMoyxVISLVzYQ
- Facebook: https://www.facebook.com/giaphugroupcom/videos/1997540213689513/

# Snapshot

## The popup customer login form

![ScreenShot](https://raw.githubusercontent.com/php-cuong/magento2-customer-ajax-login-and-registration/master/Snapshot/login-form.png)

## The popup customer registration form

![ScreenShot](https://raw.githubusercontent.com/php-cuong/magento2-customer-ajax-login-and-registration/master/Snapshot/registration-form.png)
